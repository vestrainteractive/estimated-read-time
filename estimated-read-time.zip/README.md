# estimated-read-time

Simple plugin to display the estimated read time on a page, post or template.

To use:

1: Activate the plugin

2: Add the shortcode [estimated_read_time] anywhere you normally put a shortcode.

This plugin is provided as-is.  No support is offered.  At the time of creation it is verified to work with php8.3 and wordpress 6.  
